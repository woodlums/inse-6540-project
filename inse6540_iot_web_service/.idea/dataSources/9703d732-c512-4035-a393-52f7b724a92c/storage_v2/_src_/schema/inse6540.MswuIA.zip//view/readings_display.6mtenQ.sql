create definer = remote@`%` view readings_display as
select `inse6540`.`readings`.`date_time`                AS `Timestamp`,
       `inse6540`.`readings`.`value`                    AS `Value`,
       `inse6540`.`units`.`unit_name`                   AS `Unit`,
       `inse6540`.`reading_type`.`type_name`            AS `Type`,
       `inse6540`.`readings`.`hashed_value`             AS `Unique Hash`,
       if(`inse6540`.`readings`.`bc_written`, '✔', '-') AS `In Blockchain`
from ((`inse6540`.`readings` join `inse6540`.`units`) join `inse6540`.`reading_type`)
where `inse6540`.`units`.`unit_code` = `inse6540`.`readings`.`unit`
  and `inse6540`.`reading_type`.`type_code` = `inse6540`.`readings`.`reading_type`;

